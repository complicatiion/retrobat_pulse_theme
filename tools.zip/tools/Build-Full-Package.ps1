﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourceThemePath,

    [Parameter(Mandatory = $false)]
    [string]$OutputZip = ".\retrobat_pulse_theme_es-de.zip"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$SourceThemePath = (Resolve-Path $SourceThemePath).Path
$required = @("theme.xml", "assets", "_res", "art")
foreach ($item in $required) {
    if (-not (Test-Path (Join-Path $SourceThemePath $item))) {
        throw "Source theme is incomplete. Missing: $item"
    }
}

$packageRoot = Split-Path -Parent $PSScriptRoot
$overlay = Join-Path $packageRoot "overlay"
if (-not (Test-Path $overlay)) { throw "Compatibility overlay not found: $overlay" }

$temp = Join-Path ([System.IO.Path]::GetTempPath()) ("PulseRetroBatBuild_" + [guid]::NewGuid().ToString("N"))
$themeOut = Join-Path $temp "Pulse-RetroBat"

try {
    Copy-Item -Path $SourceThemePath -Destination $themeOut -Recurse -Force
    Copy-Item -Path (Join-Path $overlay "*") -Destination $themeOut -Recurse -Force

    $resolvedOutput = [System.IO.Path]::GetFullPath($OutputZip)
    if (Test-Path $resolvedOutput) { Remove-Item $resolvedOutput -Force }
    Compress-Archive -Path $themeOut -DestinationPath $resolvedOutput -CompressionLevel Optimal
    Write-Host "Full RetroBat theme package created:" -ForegroundColor Green
    Write-Host $resolvedOutput
}
finally {
    if (Test-Path $temp) { Remove-Item $temp -Recurse -Force -ErrorAction SilentlyContinue }
}
