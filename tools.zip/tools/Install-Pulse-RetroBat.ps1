﻿[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RetroBatRoot,

    [Parameter(Mandatory = $false)]
    [string]$SourceThemePath,

    [Parameter(Mandatory = $false)]
    [string]$ThemeFolderName = "Pulse-RetroBat"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Assert-ThemeSource([string]$Path) {
    $required = @("theme.xml", "assets", "_res", "art")
    foreach ($item in $required) {
        if (-not (Test-Path (Join-Path $Path $item))) {
            throw "Source theme is incomplete. Missing: $item in $Path"
        }
    }
}

$RetroBatRoot = (Resolve-Path $RetroBatRoot).Path
$themesRoot = Join-Path $RetroBatRoot "emulationstation\.emulationstation\themes"
if (-not (Test-Path $themesRoot)) {
    New-Item -ItemType Directory -Force -Path $themesRoot | Out-Null
}

$tempRoot = $null
try {
    if ([string]::IsNullOrWhiteSpace($SourceThemePath)) {
        $tempRoot = Join-Path ([System.IO.Path]::GetTempPath()) ("PulseRetroBat_" + [guid]::NewGuid().ToString("N"))
        New-Item -ItemType Directory -Force -Path $tempRoot | Out-Null
        $archive = Join-Path $tempRoot "pulse-main.zip"
        $url = "https://github.com/complicatiion/batocera_pulse_theme/archive/refs/heads/main.zip"
        Write-Host "Downloading original Pulse Theme..."
        Invoke-WebRequest -Uri $url -OutFile $archive -UseBasicParsing
        Expand-Archive -Path $archive -DestinationPath $tempRoot -Force
        $SourceThemePath = Join-Path $tempRoot "batocera_pulse_theme-main"
    }
    else {
        $SourceThemePath = (Resolve-Path $SourceThemePath).Path
    }

    Assert-ThemeSource $SourceThemePath

    $destination = Join-Path $themesRoot $ThemeFolderName
    if (Test-Path $destination) {
        $backup = "$destination.backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')"
        Write-Host "Existing theme found. Backup: $backup"
        Move-Item -Path $destination -Destination $backup
    }

    Write-Host "Copying original Pulse Theme assets..."
    Copy-Item -Path $SourceThemePath -Destination $destination -Recurse -Force

    $packageRoot = Split-Path -Parent $PSScriptRoot
    $overlay = Join-Path $packageRoot "overlay"
    if (-not (Test-Path $overlay)) {
        throw "Compatibility overlay not found: $overlay"
    }

    Write-Host "Applying RetroBat compatibility overlay..."
    Copy-Item -Path (Join-Path $overlay "*") -Destination $destination -Recurse -Force

    $requiredFinal = @(
        (Join-Path $destination "theme.xml"),
        (Join-Path $destination "theme2.xml"),
        (Join-Path $destination "assets"),
        (Join-Path $destination "_res"),
        (Join-Path $destination "art")
    )
    foreach ($item in $requiredFinal) {
        if (-not (Test-Path $item)) { throw "Installation validation failed: $item is missing." }
    }

    Write-Host ""
    Write-Host "Pulse-RetroBat installed successfully:" -ForegroundColor Green
    Write-Host $destination
    Write-Host "Select it in RetroBat: Main Menu -> UI Settings -> Theme Set"
}
finally {
    if ($tempRoot -and (Test-Path $tempRoot)) {
        Remove-Item -Path $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}
